[![Stories in Ready](https://badge.waffle.io/FirstGGJ2016/ggj2016.png?label=ready&title=Ready)](http://waffle.io/FirstGGJ2016/ggj2016)
