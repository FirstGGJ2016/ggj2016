{

"metadata":
{
"sourceFile": "Ouija_Board.max",
"generatedBy": "3ds max ThreeJSExporter",
"formatVersion": 3,
"vertices": 4,
"normals": 4,
"colors": 0,
"uvs": 4,
"triangles": 2,
"materials": 1
},

"materials": [
{
"DbgIndex" : 0,
"DbgName"  : "Material #46",
"colorDiffuse"  : [0.5880, 0.5880, 0.5880],
"colorAmbient"  : [0.5880, 0.5880, 0.5880],
"colorSpecular"  : [0.9000, 0.9000, 0.9000],
"transparency"  : 1.0,
"specularCoef"  : 10.0,
"vertexColors" : false
}

],

"vertices": [-250.0,0.0,100.0,250.0,0.0,100.0,-250.0,0.0,-100.0,250.0,0.0,-100.0],

"normals": [0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0],

"colors": [],

"uvs": [[0.0,0.3,0.0,0.7,1.0,0.3,1.0,0.7]],

"faces": [42,0,1,3,0,1,3,2,0,1,3,42,3,2,0,0,2,0,1,3,2,0]

}