Template.waitPerson.rendered = function() {
  Room.rtc = new RTC(false, Room.getRoom()._id);
};
