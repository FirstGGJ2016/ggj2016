Template.game.rendered = Game.createRoom;
